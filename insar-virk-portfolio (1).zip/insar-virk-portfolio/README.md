# Insar Virk | Virk Design Studio portfolio

A single-page portfolio website. All HTML, CSS and JavaScript live in `index.html`.

## Publish on GitHub Pages
1. Create a new repository on GitHub (for example `insar-virk-portfolio`).
2. Upload everything in this folder (`index.html`, `README.md`, `images/`) to the repository root.
3. Open Settings > Pages. Under "Build and deployment", set Source to "Deploy from a branch", choose the `main` branch and the `/ (root)` folder, then Save.
4. After a minute or two your site is live at `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

## Add your own designs
Open `index.html` and find the `WORK` list in the script near the bottom. Each project has `src: ""`.
Put the path to your exported Canva image there, for example `src: "images/logo-1.png"`, and change the `title` and `tag` to match.
Save your image files in the `images/` folder. Projects without a `src` show a purple "Sample" placeholder.

## WhatsApp contact
WhatsApp is the only contact method. The number and link (`https://wa.me/923054455446`) are set in the `CONFIG` block of the script and in the `href` of the WhatsApp links in the HTML.
The contact form opens a WhatsApp chat with the visitor's name and project details already typed in.
