Put your exported Canva designs (PNG or JPG) in this folder, then reference them from the WORK list in index.html, e.g. src: "images/logo-1.png".
